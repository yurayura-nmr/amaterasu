from . import bruker
from . import convert
from . import nmrml
from . import pipe
from . import rnmrtk
from . import simpson
from . import sparky
from . import tecmag
from . import varian
# replicate varian namespace in agilent
from . import varian as agilent
from . import table
